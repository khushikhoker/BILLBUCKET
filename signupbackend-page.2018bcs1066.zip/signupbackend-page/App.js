import React, { Component } from 'react';
import {TouchableOpacity, TextInput, Text, View, StyleSheet,Alert,Image } from 'react-native';
export default class App extends Component {
  constructor(props) {
    super(props);
    
    this.state = {
      username: '',
      password: '',
      email: '',
      phoneno: '',
    };
  }
  InsertDataToServer = () =>{
        
       fetch('http://192.168.43.39/signup.php', {
         method: 'POST',
         headers: {
           'Accept': 'application/json',
           'Content-Type': 'application/json',
         },
         body: JSON.stringify({
        
           username:this.state.username ,
        
           email: this.state.email,
        
           phoneno: this.state.phoneno,
           password:this.state.password
        
         })
        
       }).then((response) => response.json())
             .then((responseJson) => {
        
       // Showing response message coming from server after inserting records.
               Alert.alert(responseJson);
        
             }).catch((error) => {
               console.error(error);
             });
        
        
         }
  onLogin() {
    const { username, password,email,phoneno } = this.state;

    Alert.alert('Credentials', `${username} + ${password} + ${email} + ${phoneno} `);
  }

  render() {
    return (
      <View style={styles.container}>
      <Image style={styles.logo} source={require('./assets/lgja.jpg')} />
        <TextInput
          value={this.state.username}
          onChangeText={(value) => this.setState({ username:value})}
          placeholder={'Username'}
          style={styles.input}
        />
        <TextInput
          value={this.state.password}
          onChangeText={(value) => this.setState({ password : value })}
          placeholder={'Password'}
          secureTextEntry={true}
          style={styles.input}
        />
        <TextInput
          value={this.state.email}
          onChangeText={(value) => this.setState({ email:value })}
          placeholder={'Email Id'}
          style={styles.input}
        />
        <TextInput
          value={this.state.phoneno}
          onChangeText={(value) => this.setState({ phoneno : value})}
          placeholder={'Phone No'}
          style={styles.input}
        />
        
        <TouchableOpacity>
        <Text style={{height: 40,width: 240, borderColor: 'gray', borderWidth: 2, textAlign:'center', backgroundColor:'#41C2A3',borderRadius: 10,marginTop: 10, fontWeight:"bold",fontSize:20,fontStyle: "ockwell"}} onPress={this.InsertDataToServer}>Register</Text>
      </TouchableOpacity>

      <Text style={{color:"white",marginTop:5,fontSize:14,flexDirection:"row"}}>Don't have an account? Login</Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-end',
    backgroundColor: '#000000',
    paddingBottom:40,
  },
  input: {
    width: 240,
    height: 40,
    padding: 10,
    borderWidth: 1,
    borderColor: 'white',
    marginBottom: 15,
    borderRadius: 10,
  },
  logo: {
    height: 150,
    width: 250,
  },
});